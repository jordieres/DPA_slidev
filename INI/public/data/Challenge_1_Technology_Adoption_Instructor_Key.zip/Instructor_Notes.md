# Instructor Key and Expected Analytical Signals

## Intended high-level findings
These are not single correct answers, but patterns supported by the synthetic evidence.

1. North Plant is the strongest candidate for a rapid, lower-risk pilot because of data availability, local sponsorship and technical readiness.
2. South Plant has the greatest operational need but is a poor candidate for a first AI pilot without prior infrastructure and data-quality work.
3. Automated reporting or quality analytics may produce faster and more measurable value than predictive maintenance.
4. Employee adoption is associated with perceived usefulness, digital confidence, trust and training willingness, and negatively associated with job-threat and privacy concern.
5. Readiness differs materially by site, department and role; an overall average hides important segments.
6. Vendor costs are not directly comparable without normalising taxes, internal labour, training, integration and exit costs.
7. Vendor A offers speed and integration but creates lock-in and commercial concentration risk.
8. Vendor B reduces single-vendor dependency but increases integration and accountability complexity.
9. Vendor C builds strategic capability but requires scarce internal capacity and creates delivery uncertainty.
10. The strongest recommendations should use stage gates, measurable KPIs, human oversight and explicit stopping criteria.

## Expected data-preparation actions
- normalise site and department labels;
- trim identifiers and inspect duplicates;
- reconcile mixed binary encodings;
- identify or correct impossible ages and tenure values;
- handle missing scale values transparently;
- standardise percentage and currency formats;
- document whether duplicates are removed, merged or retained;
- retain a transformation log;
- avoid imputing critical values without sensitivity analysis.

## Competition design
Use the common course rubric plus:
- 10% quantitative evidence quality;
- 5% robustness to hidden scenario;
- 5% clarity and speed of executive response.

## Suggested hidden checks
- Ask groups to reproduce one KPI live.
- Ask why their chosen site is preferable to the site with the highest operational need.
- Ask which result depends most strongly on an assumption.
- Ask which data field they would improve before implementation.
- Ask how their recommendation changes under one hidden scenario.
