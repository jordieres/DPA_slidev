# Stakeholder Interview Extracts

## Chief Executive Officer
“We need a visible improvement within a year, but I do not want another technology programme that creates dashboards without changing decisions. A pilot is acceptable if it can scale.”

## Chief Financial Officer
“The proposals are not financially comparable. Some include internal labour and some do not. Benefits must be risk-adjusted, and we need explicit stopping criteria before committing to a full rollout.”

## Chief Information Officer
“North Plant is technically ready, but its managers may underestimate integration work. South Plant has the largest potential benefit, yet it also has the weakest infrastructure. Data lineage and access control must be designed before deployment.”

## North Plant Manager
“We already have reliable MES data and a strong maintenance team. I would start with predictive maintenance and prove value quickly. However, I do not want corporate IT slowing down every experiment.”

## South Plant Manager
“Our downtime is high because systems and sensors are old. If the pilot goes to North again, South will fall further behind. We need investment, not another readiness assessment.”

## Maintenance Supervisor
“The CMMS failure codes are inconsistent and technicians often write free text. AI may help, but only after we agree on basic coding practices. Experienced technicians fear that their judgement will be ignored.”

## Quality Director
“Quality analytics could create value earlier than predictive maintenance because defect images and inspection data are already available at North and Central. The vendor proposals barely discuss false alarms.”

## HR Director
“Training capacity is limited. Adoption will depend on supervisors and peer champions, not only on e-learning. We also need clarity on which tasks change and how performance will be assessed.”

## Employee Representative
“We are not opposed to technology, but consultation must happen before employee-level monitoring or productivity scoring. There must be no automated disciplinary decision and no hidden individual ranking.”

## Data Protection Officer
“Operational data may become personal data when linked to individual shifts or user accounts. The purpose, retention period, access rights and human oversight need to be explicit.”
