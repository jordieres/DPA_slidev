# Challenge 1 Student Data Package

## Files
1. Company profile
2. Raw employee survey
3. Raw baseline performance data
4. Raw site-readiness data
5. Vendor proposals
6. Stakeholder interviews
7. Risk and policy extracts
8. External implementation cases
9. Draft data dictionary

## Important
The package intentionally contains:
- missing values;
- duplicated or near-duplicated records;
- inconsistent category labels;
- mixed encodings;
- implausible values;
- incompatible percentage and currency formats;
- contradictory qualitative evidence;
- non-comparable vendor assumptions.

Students must not silently remove or correct data. Every material cleaning or transformation decision should be documented in a reproducible data-preparation log.

## Minimum expected outputs
- corrected data dictionary;
- data-quality report;
- reproducible clean dataset;
- evidence matrix;
- technology-adoption assessment;
- vendor comparison;
- pilot-site and use-case recommendation;
- phased roadmap;
- KPI and governance framework;
- validation and sensitivity analysis.
