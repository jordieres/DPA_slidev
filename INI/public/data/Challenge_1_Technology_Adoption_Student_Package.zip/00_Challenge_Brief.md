# Challenge 1 — Technology Adoption Decision

## Decision question
Should Orion Manufacturing adopt an AI-enabled operations platform, and if so, which option, pilot site, initial use case and governance conditions should be selected?

## Competition
All groups receive the same package. Solutions will be assessed using the common course rubric and a challenge-specific performance layer.

## Required management deliverable
Prepare a Board Decision Dossier containing:
- executive recommendation;
- problem formulation and success criteria;
- data-quality and evidence assessment;
- adoption-readiness diagnosis;
- comparison of implementation alternatives;
- pilot-site and use-case selection;
- cost, benefit, risk and sensitivity analysis;
- implementation roadmap;
- governance and workforce conditions;
- KPIs, review gates and stopping criteria.

## Technical annex
Include:
- prompt architecture and representative interactions;
- reproducible data-preparation steps;
- scripts, formulas or analytical workflow;
- assumptions register;
- validation tests;
- traceability statement;
- limitations and unresolved uncertainties.

## Constraint
A persuasive narrative without auditable evidence, reproducible analysis and validation will not be considered a strong solution.
