# Orion Manufacturing: Company Profile

## Company overview
Orion Manufacturing is a fictional European mid-sized industrial company producing precision components for transport, energy and industrial-equipment customers.

- Employees: approximately 680
- Production sites: North Plant, Central Plant and South Plant
- Headquarters: Madrid
- Annual revenue: approximately EUR 185 million
- Main functions: production, maintenance, quality, supply chain, engineering, sales, finance, HR and IT
- Current strategic priorities:
  1. Reduce unplanned downtime.
  2. Improve first-pass yield.
  3. Shorten management-reporting lead time.
  4. Retain operational knowledge.
  5. Meet cybersecurity and data-governance expectations.

## Technology-adoption decision
The Executive Committee is considering an AI-enabled operations platform covering:

- predictive-maintenance support;
- quality-event analysis;
- production-performance analytics;
- document and knowledge assistance;
- automated management reporting.

The company must decide:

1. Whether adoption should proceed.
2. Which implementation alternative should be chosen.
3. Which site and use case should be selected for the first pilot.
4. Which governance, workforce and change-management conditions are required.
5. Which KPIs and stopping criteria should be used.

## Current systems landscape
- ERP: common across the company, but master-data quality varies by site.
- MES: available at North and Central; partial deployment at South.
- CMMS: used by maintenance, with uneven coding practices.
- Document repositories: shared drives, SharePoint and local folders.
- BI: several Power BI dashboards, not consistently governed.
- Identity and access management: centralised for core systems.
- OT connectivity: stronger at North, fragmented at Central, limited at South.

## Known organisational tensions
- Operations wants rapid, practical gains.
- Finance requires a clear, auditable business case.
- IT is concerned about integration, security and vendor lock-in.
- Employee representatives require consultation and safeguards.
- Some managers expect AI to compensate for poor data quality.
- Several experienced employees fear loss of autonomy or job redesign.

## Student task
Prepare a professionally defensible recommendation for the Executive Committee. The recommendation must integrate quantitative and qualitative evidence, identify data limitations, compare alternatives, propose a phased roadmap and define measurable success criteria.

The package intentionally contains incomplete, inconsistent and partially contradictory information. Data cleaning and evidence reconciliation are part of the challenge.
