# Vendor Proposals

## Vendor A — Atlas Enterprise AI Suite
- Commercial model: enterprise subscription
- Three-year licence: EUR 1,420,000
- Initial implementation services: EUR 620,000
- Estimated implementation: 8–10 months
- Included modules: predictive maintenance, quality analytics, reporting assistant, knowledge assistant
- Integration: certified ERP and MES connectors; CMMS connector requires configuration
- Data hosting: EU cloud region
- Data ownership: customer retains ownership; vendor may process telemetry for service improvement unless opted out
- Support: 24/7 premium support
- Claimed benefits: 18–25% reduction in unplanned downtime within 18 months
- Risks: high switching costs; proprietary workflow layer; annual price indexation
- Evidence supplied: two customer case studies, one audited and one vendor-authored
- Cybersecurity: ISO 27001 certification; SOC 2 Type II report available under NDA

## Vendor B — Modular Specialist Stack
- Commercial model: separate subscriptions for three specialist products
- Three-year licence estimate: EUR 920,000
- Integration and orchestration services: EUR 780,000
- Estimated implementation: 10–14 months
- Included modules: predictive maintenance, visual quality analytics and document assistant
- Integration: APIs available, but Orion must manage identity, monitoring and cross-product logging
- Data hosting: two EU cloud providers
- Data ownership: contract varies by module
- Support: business-hours support plus paid escalation
- Claimed benefits: best-of-breed performance and lower vendor dependence
- Risks: integration complexity; fragmented accountability; inconsistent user experience
- Evidence supplied: technical benchmarks and four customer references
- Cybersecurity: certifications differ by module

## Vendor C — Orion Build-and-Partner
- Commercial model: internal product team plus external consultancy
- Three-year external cost estimate: EUR 1,050,000
- Internal staffing requirement: 6–8 FTE
- Estimated first pilot: 5–7 months; enterprise rollout uncertain
- Included scope: common data layer, reporting assistant and one predictive-maintenance use case
- Integration: tailored to Orion systems
- Data hosting: Orion-controlled cloud environment
- Data ownership: fully retained by Orion
- Support: internal team with consultancy escalation
- Claimed benefits: strategic capability building and reduced lock-in
- Risks: scarce skills; key-person dependency; uncertain maintenance burden
- Evidence supplied: architecture proposal and consultant references
- Cybersecurity: aligned to Orion controls, subject to internal implementation quality

## Commercial caveats
- None of the vendors includes the cost of sensor replacement at South Plant.
- Training estimates assume no major role redesign.
- The proposals use different benefit baselines and cannot be compared without normalisation.
- Vendor A excludes taxes from cost tables; Vendor B includes taxes in one appendix; Vendor C excludes internal labour from the headline estimate.
- All vendors assume that Orion will provide sufficiently clean maintenance and production data.
