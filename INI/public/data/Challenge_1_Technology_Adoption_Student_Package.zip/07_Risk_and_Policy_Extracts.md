# Risk and Policy Extracts

## Information Security Policy
- New cloud services require security review before production use.
- Least-privilege access and multi-factor authentication are mandatory.
- Production and experimental environments must be separated.
- Security logs must be retained for at least 12 months.

## Data Protection and Employee Data
- Employee-level monitoring requires a documented lawful purpose and consultation.
- Automated decisions with significant effects on employees are prohibited without meaningful human review.
- Data minimisation and retention limits must be defined.
- Special-category personal data must not be used in the pilot.

## Procurement Policy
- Purchases above EUR 750,000 require competitive review.
- Total cost of ownership must include internal labour, integration, training, migration and exit costs.
- Material subcontractors must be disclosed.
- Vendor exit provisions are mandatory for critical systems.

## AI Governance Principles
- Every production AI use case must have a named business owner.
- Outputs affecting operations must be traceable to source data and model version.
- High-impact recommendations require human approval.
- Performance, drift, incidents and overrides must be monitored.
- A rollback or manual fallback procedure must exist.

## Workforce Consultation
- Material changes to work organisation require consultation with employee representatives.
- Training must be accessible to all affected roles.
- The company should document how automation changes responsibilities and skill requirements.
